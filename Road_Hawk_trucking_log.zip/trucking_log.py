import csv
import os
import shutil
from datetime import datetime
from geopy.geocoders import Nominatim

# Function to get location based on city or zip code
def get_location():
    geolocator = Nominatim(user_agent="trucking_log")
    location_input = input("Enter starting city or zip code: ")
    location = geolocator.geocode(location_input)
    return location.address if location else "Unknown Location"

# Function to log data to a CSV file
def save_to_csv(timestamp, driver_name, truck_number, miles_driven, fuel_used, load_weight, hours_driven, avg_speed, mpg, fuel_cost, location):
    file_exists = os.path.isfile("trucking_log.csv")

    with open("trucking_log.csv", "a", newline="") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["Timestamp", "Driver", "Truck", "Miles", "Fuel Used", "Load Weight", "Time Driven", "Avg Speed", "MPG", "Fuel Cost", "Location"])
        writer.writerow([timestamp, driver_name, truck_number, miles_driven, fuel_used, load_weight, hours_driven, avg_speed, mpg, fuel_cost, location])

# Function to save log to a text file and create a backup
def save_log(timestamp, driver_name, truck_number, miles_driven, fuel_used, load_weight, hours_driven, avg_speed, mpg, fuel_cost, location):
    with open("trucking_log.txt", "a") as log:
        log.write(f"\n[{timestamp}]\nDriver: {driver_name}\nTruck: {truck_number}\nMiles: {miles_driven}\nFuel: {fuel_used} gallons\n"
                  f"Load Weight: {load_weight} lbs\nTime: {hours_driven} hours\nAvg Speed: {avg_speed} MPH\nMPG: {mpg}\nFuel Cost: ${fuel_cost}\n"
                  f"Location: {location}\n---\n")
    # Create a backup
    shutil.copy("trucking_log.txt", "trucking_log_backup.txt")

# Function to display past logs
def view_logs():
    if os.path.exists("trucking_log.txt"):
        with open("trucking_log.txt", "r") as log:
            print("\n==== Past Trucking Logs ====")
            print(log.read())
    else:
        print("\n🚫 No logs found. Please enter a new log first.")

# Main loop
while True:
    print("\n==== Trucking Log Menu ====")
    print("1. Enter New Log")
    print("2. View Past Logs")
    print("3. Exit")

    choice = input("Select an option: ")

    if choice == "1":
        # Get trucking details
        driver_name = input("Enter Driver Name: ")
        truck_number = input("Enter Truck Number: ")
        miles_driven = float(input("Enter Miles Driven: "))
        fuel_used = float(input("Enter Fuel Used (gallons): "))
        load_weight = float(input("Enter Load Weight (pounds): ").replace(",", ""))
        hours_driven = float(input("Enter Time Spent Driving (hours): "))
        fuel_price = float(input("Enter Current Fuel Price per Gallon: $"))

        # Calculate values
        mpg = round(miles_driven / fuel_used, 2) if fuel_used > 0 else "N/A (Fuel used cannot be zero)"
        avg_speed = round(miles_driven / hours_driven, 2) if hours_driven > 0 else "N/A (Time must be greater than zero)"
        fuel_cost = round(fuel_used * fuel_price, 2)
        location = get_location()

        # Get current timestamp
        log_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Save logs
        save_log(log_timestamp, driver_name, truck_number, miles_driven, fuel_used, load_weight, hours_driven, avg_speed, mpg, fuel_cost, location)
        save_to_csv(log_timestamp, driver_name, truck_number, miles_driven, fuel_used, load_weight, hours_driven, avg_speed, mpg, fuel_cost, location)

        print("✅ Log saved successfully!")

    elif choice == "2":
        view_logs()

    elif choice == "3":
        print("🚛 Exiting program. Have a great day!")
        break

    else:
        print("❌ Invalid choice. Please enter 1, 2, or 3.")
